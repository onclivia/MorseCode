package com.tppa.morsecode;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class WriteSentenceActivity extends AppCompatActivity {

    public String phone_number = "";
    public String sentence = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write_sentence);

        //Get Morse Code actions

        EditText sentence_edit = findViewById(R.id.writeSentenceEdit);
        sentence = sentence_edit.getText().toString();

        Button getMorseCodeBtn = findViewById(R.id.getMorseCodeBtn);
        getMorseCodeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getMorseCode();
            }
        });


        //Send sms actions

        Button sendBtn = findViewById(R.id.sendSmsBtn);


        sendBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                //sendSMSMessage();
            }
        });
    }

    public void getMorseCode(){

    }

    public void sendSMSMessage(){
        String sms = convertSentenceToMorseCode();
        try {
            SmsManager smgr = SmsManager.getDefault();
            smgr.sendTextMessage(phone_number, null, sms, null, null);
            Toast.makeText(this, "SMS Sent Successfully", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS Failed to Send, Please check your balance", Toast.LENGTH_SHORT).show();
        }
    }

    public String convertSentenceToMorseCode(){
        return "";
    }
}
