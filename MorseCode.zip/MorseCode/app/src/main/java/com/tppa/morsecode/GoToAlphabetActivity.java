package com.tppa.morsecode;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class GoToAlphabetActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_go_to_alphabet);
    }
}
