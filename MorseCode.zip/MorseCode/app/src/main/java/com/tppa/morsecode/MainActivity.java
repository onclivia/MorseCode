package com.tppa.morsecode;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.Image;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    ImageButton btnON;
    ImageButton btnOFF;
    String CHANNEL_ID = "CHECK_LED";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnON = findViewById(R.id.check_led_btn_on);
        btnOFF = findViewById(R.id.check_led_btn_off);

    }

    public void checkLedButtonClicked(View view){

        //make ON button visible


        redLedStart(0);
        btnOFF.setVisibility(View.GONE);
        btnON.setVisibility(View.VISIBLE);
    }

    public void checkLedButtonUnclicked(View view) {

        btnON.setVisibility(View.GONE);
        btnOFF.setVisibility(View.VISIBLE);
    }

    private void redLedStart(int notificationId)
    {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);

        NotificationCompat.Builder builder;
        createNotificationChannel();

        Notification notif = new Notification.Builder(MainActivity.this)
                .setSmallIcon(R.drawable.notification_icon)
                .setContentTitle("Morse Code")
                .setContentText("Led should start")
                .setColor(Color.GREEN)
                .setLights(255, 1, 0)
                .setContentIntent(pendingIntent)
                .setStyle(new Notification.BigTextStyle().bigText("..."))
                .setChannelId(CHANNEL_ID)
                .setPriority(Notification.PRIORITY_HIGH)
                .build();
        nm.notify(LED_NOTIFICATION_ID, notif);



        Notification notification = builder.build();
        notification.flags |= Notification.FLAG_SHOW_LIGHTS;

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(notificationId, notification);
    }

    private void createNotificationChannel(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.channel_name);
            String description = getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.shouldShowLights();
            channel.setLightColor(Color.GREEN);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }

    }

    public void writeSentenceActivity(View view){
        Intent intent = new Intent(getBaseContext(),   WriteSentenceActivity.class);
        startActivity(intent);
    }

    public void goToAlphabetActivity(View view){
        Intent intent = new Intent(getBaseContext(),   GoToAlphabetActivity.class);
        startActivity(intent);
    }

    public void decryptSentenceActivity(View view){
        Intent intent = new Intent(getBaseContext(),   DecryptSentenceActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onPause(){
        super.onPause();
        Log.d("onPause","onPause");
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.d("onResume", "onResume");
    }

    @Override
    protected void onStop(){
        super.onStop();
        Log.d("onStop", "onStop");
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.d("onDestroy", "onDestroy");
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState){
        super.onRestoreInstanceState(savedInstanceState);
        Log.d("","onRestoreInstanceState");
    }

    @Override
    protected void onSaveInstanceState(Bundle outState){
        super.onSaveInstanceState(outState);
        Log.d("","onSaveInstanceState");
    }
}
